# NovaStore — Static E-commerce Starter

A responsive multi-page storefront built with plain HTML, CSS and JavaScript. It is designed to deploy as a static site on Vercel.

## Included pages
- `index.html` — home page
- `shop.html` — product catalogue, search, category filter and sorting
- `product.html?id=product-id` — product detail page
- `cart.html` — browser-based cart
- `checkout.html` — demo checkout form
- `success.html` — demo order confirmation
- `about.html`, `contact.html`, `404.html`

## Run locally
1. Extract the ZIP file.
2. Open the `novastore-ecommerce` folder in VS Code.
3. Install the VS Code extension **Live Server** (by Ritwick Dey), if it is not installed.
4. Right-click `index.html` and choose **Open with Live Server**.
5. Your browser should open the site. You can also use any local static-file server.

Do not open files by double-clicking if you want to test all browser features consistently; use Live Server.

## Deploy to Vercel (beginner method: GitHub)
1. Create or sign in to a GitHub account at https://github.com.
2. Create a new repository. Name it `novastore-ecommerce`. Choose Public or Private, then create it.
3. Extract this ZIP on your computer. Open the extracted `novastore-ecommerce` folder.
4. On your new GitHub repository page, choose **Add file → Upload files**.
5. Open the extracted folder on your computer and select all its contents (the HTML files, `assets` folder and `README.md`). Upload the contents, not an extra enclosing folder.
6. Wait for the upload to finish, enter a commit message such as `Add NovaStore website`, then click **Commit changes**.
7. Go to https://vercel.com and sign up or log in. You can choose **Continue with GitHub**.
8. In Vercel, click **Add New → Project**.
9. Find `novastore-ecommerce` in the Git repository list and click **Import**. If it is missing, use the GitHub connection/configuration option to grant Vercel access to that repository.
10. In the project configuration:
    - Framework Preset: **Other**
    - Root Directory: `./`
    - Build Command: leave blank / override disabled
    - Output Directory: leave blank or use `.`
    - Install Command: leave blank / override disabled
11. Click **Deploy**. This is a plain static website; no build or install command is needed.
12. When deployment finishes, click **Visit** to open the live website. Vercel will also show a URL ending in `vercel.app`.

## Updating the site later
1. Edit the files in VS Code.
2. Save your changes.
3. Upload the changed files to the same GitHub repository (or push a Git commit).
4. Vercel automatically creates a new deployment. Refresh your website after it finishes.

## Customise the store
- Brand name and text: edit the HTML files. Search for `NovaStore` and `nova`.
- Products, prices, categories, images and descriptions: edit `assets/js/products.js`.
- Colours, typography and layout: edit `assets/css/style.css`.
- Contact email: replace `hello@example.com` in `contact.html` and footer sections.
- Shipping threshold and shipping fee: search in `assets/js/app.js` for `1999` and `99`.

## Important limitations before using this for a real business
This is a front-end demo, not a complete production commerce platform:
- Cart data is stored in the visitor's browser using localStorage.
- Checkout only validates the form and creates a demo confirmation in the browser.
- No real payment gateway is connected. Never collect card details with this starter.
- Contact and newsletter forms only show demo confirmation; they do not send or store messages.
- Products are sample content and stock is not tracked.
- There is no admin panel, customer login, database, order management, tax calculation or shipping integration.
- Product images are loaded from Unsplash, and Google Fonts are loaded online. Replace these with properly licensed assets for your business.

For real orders, connect a secure backend or commerce platform and a payment provider (for example, a supported payment gateway in your country). Never put secret API keys in front-end JavaScript.
